# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time    : 2021/8/4 15:15
# @Author  : 薛定谔的猫
# 公众号   : 黑猫编程
# 淘宝店铺 : 黑猫编程

info = {"name":"薛定谔的猫", "age":25}
print(info)
print(info.get("height"))

# info2 = dict(name="cat", age=26)
# print(info2)

# print("name2" in info)

info["height"] = 182
print(info)

del info["height"]
print(info)

print(info.keys())
print(info.values())
print(info.items())

for i in info.items():
    print(i)

