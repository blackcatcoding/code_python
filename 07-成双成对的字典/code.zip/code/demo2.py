# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time    : 2021/8/4 15:27
# @Author  : 薛定谔的猫
# 公众号   : 黑猫编程
# 淘宝店铺 : 黑猫编程

items = ["Fruits", "Books", "Others"]
prices = [80, 90, 100, 110, 120]

d = zip(items, prices)
print(list(d))

d = {item.upper():price for item,price in zip(items,prices)}
print(d)