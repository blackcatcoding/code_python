n, x = [for i in input().split()]

li = input().split()
  
for i in li:
	if i != x:
		print(i, end=" ")