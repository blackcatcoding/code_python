n = int(input())
  
print("%d%d" % (n % 10, n // 10))