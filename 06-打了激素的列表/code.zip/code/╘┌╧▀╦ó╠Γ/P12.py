li = [int(i) for i in input().split()]
print(max(li))