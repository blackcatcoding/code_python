a, b = [int(i) for i in input().split()]

print((a * 10 + b) // 19)