# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time    : 2021/12/30 22:54
# @Author  : 黑猫
# 公众号   : 黑猫编程
# 网址     : http://www.blackcat1995.com/

# s = input()
# print(s, type(s)) # "2 3"
#
# li = s.split()
# print(li)

s = 'A|B|C|D|E|F'
li = s.split('|')
print(li)