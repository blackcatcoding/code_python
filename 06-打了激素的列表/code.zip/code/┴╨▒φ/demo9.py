# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author  : 薛定谔的猫
# ghz      : 黑猫编程
# WeChat   : blackcatcoding

# 1 1 2 3 5 8 13

n = int(input("n >> "))
fibs = [0, 1]

for i in range(2, n+1):
    fibs.append(fibs[i-1]+fibs[i-2])
print(fibs)
print(fibs[n])
