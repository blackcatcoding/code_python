# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author  : 薛定谔的猫
# ghz      : 黑猫编程
# WeChat   : blackcatcoding

li = [1, 2, 3, 4, 5, "hello"]

li.append("cat")
print(li)

li.append([1, 2, 3])
print(li)

li.extend([1, 2, 3])
print(li)

# li.extend(10)
# print(li)
# TypeError: 'int' object is not iterable

li.insert(3, "aaa")
print(li)

li2 = [4, 5, 6]
li[12:] = li2

print(li)