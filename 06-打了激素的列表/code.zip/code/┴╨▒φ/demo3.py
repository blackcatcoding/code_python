# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author  : 薛定谔的猫
# ghz      : 黑猫编程
# WeChat   : blackcatcoding

li = [1, 2, 3, 4, 5, 2, "hello"]

if 1 in li:
    print("OK")
else:
    print("NO")

for i in li:
    print(i, end=" ")