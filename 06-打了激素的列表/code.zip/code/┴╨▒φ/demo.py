# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author  : 薛定谔的猫
# ghz      : 黑猫编程
# WeChat   : blackcatcoding

li = [1, 2, 3, 4, 5, 2, "hello"]
print(li)

print(li[0])
print(li[-1])

print(li.index(2))

# print(li[10])