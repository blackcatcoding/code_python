# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author  : 薛定谔的猫
# ghz      : 黑猫编程
# WeChat   : blackcatcoding

li = [3, 1, 2, 4, 5, 3, 1, 2, 4, 5]
print(len(li))

i = 0
s = 0
while i < len(li):
    s += li[i]
    i += 1

print(s)