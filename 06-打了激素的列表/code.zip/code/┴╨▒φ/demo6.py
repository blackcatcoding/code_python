# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author  : 薛定谔的猫
# ghz      : 黑猫编程
# WeChat   : blackcatcoding

li = [3, 1, 2, 4, 5]
# li.sort(reverse=True)
# print(li)

li2 = sorted(li, reverse=True)
print(li, li2)