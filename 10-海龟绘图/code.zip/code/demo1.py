# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time    : 2022/1/10 22:40
# @Author  : 黑猫
# 公众号   : 黑猫编程
# 网址     : http://www.blackcat1995.com/

# 将画笔移动到(-100, 70)的位置，绘制一根长度300的红色线段

import turtle as t

t.pu()
t.goto(-100, 70)
t.pd()

t.pencolor("red")

t.forward(300)

t.done()