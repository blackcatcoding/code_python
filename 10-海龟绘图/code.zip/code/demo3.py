# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time    : 2022/1/10 22:44
# @Author  : 黑猫
# 公众号   : 黑猫编程
# 网址     : http://www.blackcat1995.com/

# 绘制红色五角星

import turtle as t

t.color("red", "red")

t.begin_fill()

for i in range(5):
    t.forward(100)
    t.right(144)

t.end_fill()

t.done()
