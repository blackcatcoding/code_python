# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time    : 2022/1/10 22:42
# @Author  : 黑猫
# 公众号   : 黑猫编程
# 网址     : http://www.blackcat1995.com/

# 绘制边长是100的正方形，填充为黄色

import turtle as t

t.fillcolor("yellow")

t.begin_fill()

for i in range(4):
    t.forward(100)
    t.right(90)

t.end_fill()

t.done()