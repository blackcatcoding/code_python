# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author  : 薛定谔的猫
# ghz      : 黑猫编程
# WeChat   : blackcatcoding

import random

computer = random.randint(1, 3)
player = int(input("请输入你的数字：(石头-1， 剪刀-2, 布-3)："))

print("电脑出拳为：", computer)
print("玩家出拳为：", player)

if (computer==1 and player==2) or (computer==2 and player==3) or (computer==3 and player==1):
    print("不要走，决战到天亮！")
elif computer == player:
    print("心有灵犀，再来一局！")
else:
    print("恭喜你，战胜了电脑！")