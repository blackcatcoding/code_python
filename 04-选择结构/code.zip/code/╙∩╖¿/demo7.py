# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author  : 薛定谔的猫
# ghz      : 黑猫编程
# WeChat   : blackcatcoding

date = input("date >> ")

if date == "Sat" or date == "Sun":
    print("我就可以出去玩")
else:
    print("乖乖在家学习")