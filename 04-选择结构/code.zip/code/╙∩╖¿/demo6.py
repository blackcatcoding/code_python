# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author  : 薛定谔的猫
# ghz      : 黑猫编程
# WeChat   : blackcatcoding

name = input("name >> ")
passwd = input("passwd >> ")

if name == "xuyanpeng" and passwd == "123456":
    print("Login successful.")
else:
    print("Login error. Please try again!")