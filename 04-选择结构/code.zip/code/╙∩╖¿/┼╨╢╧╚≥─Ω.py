# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author  : 薛定谔的猫
# ghz      : 黑猫编程
# WeChat   : blackcatcoding

'''
判断闰年
能被4整除但是不能被100整除，或者可以被400整除
'''

year = int(input("year >> "))

if (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0):
    print("%d是闰年" % year)
else:
    print("%d是平年" % year)