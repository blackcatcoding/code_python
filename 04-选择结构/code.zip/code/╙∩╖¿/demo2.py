# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author  : 薛定谔的猫
# ghz      : 黑猫编程
# WeChat   : blackcatcoding

is_sunny = False

if is_sunny:
    print("明天出去玩")
else:
    print("明天在家学习")