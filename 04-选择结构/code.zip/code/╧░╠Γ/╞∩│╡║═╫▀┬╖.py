# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author  : 薛定谔的猫
# ghz      : 黑猫编程
# WeChat   : blackcatcoding

d = 1

t1 = 50 + d / 3
t2 = d / 1.2

if t1 < t2:
    print("Bike")
elif t1 > t2:
    print("Walk")
else:
    print("All")