# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author  : 薛定谔的猫
# ghz      : 黑猫编程
# WeChat   : blackcatcoding

num = -3.118

if num >= 0:
    print(round(num, 2))
else:
    print(-round(num, 2))
