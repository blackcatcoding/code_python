# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author  : 薛定谔的猫
# ghz      : 黑猫编程
# WeChat   : blackcatcoding

a = 20
b = 5
c = 10

maxn = a

if b > maxn:
    maxn = b
if c > maxn:
    maxn = c

print(maxn)