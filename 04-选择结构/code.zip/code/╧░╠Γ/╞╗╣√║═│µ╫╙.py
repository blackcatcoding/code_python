# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author  : 薛定谔的猫
# ghz      : 黑猫编程
# WeChat   : blackcatcoding

n = 10
x = 4
y = 9

n -= y // x

if y % x:
    n -= 1

if n < 0:
    n = 0

print(n)