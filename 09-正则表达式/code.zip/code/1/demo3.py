# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time    : 2022/1/3 14:11
# @Author  : 黑猫
# 公众号   : 黑猫编程
# 网址     : http://www.blackcat1995.com/

import re

result = re.match("[Hh]ello cat", "Hello cat")

print(result.group())

result = re.match("[Hh]ello cat", "hello cat")

print(result.group())

# 匹配0-9

result = re.match("[0123456789]", "9abcde")
print(result.group())

result = re.match("[0-9]", "8abcde")
print(result.group())

# result = re.match("[0-57-9]", "6abcde")
# print(result.group())

# \d 匹配数字0-9
result = re.match("嫦娥\d号", "嫦娥1号发送成功")
print(result.group())

result = re.match("嫦娥\d号", "嫦娥2号发送成功")
print(result.group())

result = re.match("嫦娥\d号", "嫦娥3号发送成功")
print(result.group())


