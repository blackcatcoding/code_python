# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time    : 2022/1/3 14:09
# @Author  : 黑猫
# 公众号   : 黑猫编程
# 网址     : http://www.blackcat1995.com/

import re

# result = re.match("a.b", "a\nb")

result = re.match("a.b", "acb")

print(result.group())