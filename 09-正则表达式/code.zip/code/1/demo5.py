# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time    : 2022/1/7 18:20
# @Author  : 黑猫
# 公众号   : 黑猫编程
# 网址     : http://www.blackcat1995.com/

import re

emails = ['hellocat@163.com$', 'hellocat@haha.com', 'hellocat@qq.com']

for email in emails:
    ret = re.match('[\w]{4,20}@(163|qq).com', email)
    if ret:
        print("%s 是符合要求的邮箱" % email)
    else:
        print("%s 是不符合要求的邮箱" % email)