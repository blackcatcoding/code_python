# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time    : 2022/1/3 14:31
# @Author  : 黑猫
# 公众号   : 黑猫编程
# 网址     : http://www.blackcat1995.com/

# 匹配出，一个字符串第一个字符是大写字母，后面是小写字母，可有可无

import re

result = re.match("[A-Z][a-z]*", "C")
print(result.group())

result = re.match("[A-Z][a-z]*", "Ca")
print(result.group())

result = re.match("[A-Z][a-z]*", "Cat")
print(result.group())

result = re.match("[A-Z][a-z]*", "CatA")
print(result.group())

result = re.match("[A-Z][a-z]+", "Cat")
print(result.group())

# 匹配出变量名是否有效

names = ["name1", "_name", "2name", "__name__", "name_11_abc"]

for name in names:
    result = re.match("[a-zA-Z]+[\w]*", name)

    if result:
        print("变量名【%s】符合要求" % result.group())
    else:
        print("变量名【%s】不符合要求" % name)


# 匹配出 0-99 之间的数字

result = re.match("[1-9]?[0-9]", "78")

print(result.group())

result = re.match("[1-9]?\d", "6")

print(result.group())


# 匹配密码
result = re.match("[0-9a-zA-Z]{6}", "asd789opq")
print(result.group())
