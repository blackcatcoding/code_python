# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time    : 2022/1/6 23:06
# @Author  : 黑猫
# 公众号   : 黑猫编程
# 网址     : http://www.blackcat1995.com/

import re

html_str = "<body><h2>hello cat.</h2></body>"

# ret = re.match(r"<(\w*)><(\w*)>.*</\2></\1>", html_str)
# print(ret.group())


ret = re.match(r"<(?P<name1>\w*)><(?P<name2>\w*)>.*</(?P=name2)></(?P=name1)>", html_str)
print(ret.group())