# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time    : 2022/1/6 23:11
# @Author  : 黑猫
# 公众号   : 黑猫编程
# 网址     : http://www.blackcat1995.com/

import re

# ret = re.search(r"\d+", "阅读数 1234")
# print(ret.group())

# ret = re.findall(r"\d+", "python = 1234, c++ = 3456, java = 5678")
# print(ret)

# ret = re.sub(r"\d+", "1235", "python = 1234")
# print(ret)

def add(x):
    r = int(x.group()) + 1
    return str(r)

ret = re.sub(r"\d+", add, "python = 5679")
print(ret)

