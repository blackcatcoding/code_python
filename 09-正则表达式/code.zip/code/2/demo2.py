# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time    : 2022/1/6 23:03
# @Author  : 黑猫
# 公众号   : 黑猫编程
# 网址     : http://www.blackcat1995.com/

import re

html_str = "<h1>hello cat.</h1>"

# ret = re.match("<\w*>.*</\w*>", html_str)
# print(ret.group())

ret = re.match(r"<(\w*)>.*</\1>", html_str)
print(ret.group())
