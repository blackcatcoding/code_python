# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time    : 2022/1/6 22:57
# @Author  : 黑猫
# 公众号   : 黑猫编程
# 网址     : http://www.blackcat1995.com/

import re

patt = "[a-zA-Z0-9]{4,20}@(163|126|qq).com$"
ret = re.match(patt, "cat1314@qq.com")
print(ret.group())
print(ret.group(1))

ret = re.match(patt, "cat1314@126.com")
print(ret.group())

# ret = re.match(patt, "cat1314@gmail.com")
# print(ret.group())

ret = re.match("([a-zA-Z0-9]{4,20})@(163|126|qq).com$", "cat1314@qq.com")
print(ret.group(1), ret.group(2))
