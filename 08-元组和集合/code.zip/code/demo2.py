# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time    : 2022/1/5 23:17
# @Author  : 黑猫
# 公众号   : 黑猫编程
# 网址     : http://www.blackcat1995.com/

t = (10, [20, 30], 90)
t[1].append(40)
print(t)