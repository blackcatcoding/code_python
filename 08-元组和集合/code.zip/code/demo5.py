# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time    : 2022/1/5 23:24
# @Author  : 黑猫
# 公众号   : 黑猫编程
# 网址     : http://www.blackcat1995.com/

import copy

li1 = [1, 2, 3]
li2 = copy.copy(li1)
li1[0] = "hello"
print(li1, id(li1))
print(li2, id(li2))

li3 = [[11, 22, 33], [44, 55, 66]]
li4 = copy.copy(li3)
li3[0][0] = 99
print(li3, id(li3))
print(li4, id(li4))

li5 = [[11, 22, 33], [44, 55, 66]]
li6 = copy.deepcopy(li5)
li6[0][0] = 88
print(li5, id(li5))
print(li6, id(li6))