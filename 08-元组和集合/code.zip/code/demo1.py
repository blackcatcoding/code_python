# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time    : 2022/1/5 23:12
# @Author  : 黑猫
# 公众号   : 黑猫编程
# 网址     : http://www.blackcat1995.com/

t = ('python', 'hello', 10)
print(t, type(t))

# print(t[0], t[1], t[2], t[3])

t2 = (10,)
t3 = (10)
print(type(t2), type(t3))

for i in t:
    print(i)

# t[0] = 'java'
# print(t)