# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time    : 2022/1/5 23:18
# @Author  : 黑猫
# 公众号   : 黑猫编程
# 网址     : http://www.blackcat1995.com/

a = 1
print("a =", a)
print("id(a) =", id(a))

b = 2
print("b =", b)
print("id(b) =", id(b))

c = b
print("c =", c)
print("id(c) =", id(c))