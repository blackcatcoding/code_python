# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time    : 2022/1/5 23:33
# @Author  : 黑猫
# 公众号   : 黑猫编程
# 网址     : http://www.blackcat1995.com/

s = {2, 3, 4, 5, 5, 6, 6, 6, 7, 7, 7, 7}
print(s)

s1 = set(range(6))
print(s1, type(s1))

s2 = set([1, 2, 3, 4, 8 ,9])
print(s2, type(s2))

s3 = set('python')
print(s3, type(s3))

s4 = set()
s4.add(10)
print(s4)

s4.update([90, 100, 20, 30, 40])
print(s4)

s4.pop()
print(s4)

s4.pop()
print(s4)


