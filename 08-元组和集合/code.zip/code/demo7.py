# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time    : 2022/1/5 23:38
# @Author  : 黑猫
# 公众号   : 黑猫编程
# 网址     : http://www.blackcat1995.com/

s = {10, 20, 30, 40}
s2 = {30, 40, 50, 60}
# print(s.issubset(s2))
# print(s2.issuperset(s))

print(s.intersection(s2))
print(s & s2)

print(s.union(s2))
print(s | s2)

print(s.difference(s2))
print(s - s2)

print(s.symmetric_difference(s2))
print(s ^ s2)

s = {i * i for i in range(1, 6)}
print(s)