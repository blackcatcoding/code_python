# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time    : 2022/1/5 23:21
# @Author  : 黑猫
# 公众号   : 黑猫编程
# 网址     : http://www.blackcat1995.com/

d = [1, 2, 3]
e = d
d[0] = 5
print(d, e)