# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author  : 薛定谔的猫
# ghz      : 黑猫编程
# WeChat   : blackcatcoding

a = 0b1101
print(a)

a = 15
print("a=%d" % a)
print("a=%0x" % a)
print("a=%0X" % a)
print("a=%0o" % a)