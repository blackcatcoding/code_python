# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author  : 薛定谔的猫
# ghz      : 黑猫编程
# WeChat   : blackcatcoding

print(1 + 2)
print(1 - 2)
print(1 * 2)
print(1 / 2)

print(9 // 4)

print(2 ** 3)

print(10 % 3)