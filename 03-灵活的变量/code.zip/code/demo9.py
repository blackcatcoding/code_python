# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author  : 薛定谔的猫
# ghz      : 黑猫编程
# WeChat   : blackcatcoding

a = 10

a = a + 1

print(a)

a += 2  # a = a + 2

print(a)

print(3 > 2)

print(a == 1)

s1 = "123456hahaha"
s2 = "123456hahaha"

print(s1 is s2)
print(id(s1), id(s2))