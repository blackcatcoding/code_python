# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author  : 薛定谔的猫
# ghz      : 黑猫编程
# WeChat   : blackcatcoding
from decimal import Decimal
pi = 3.14
print(type(pi))

print(0.1 + 0.2 - 0.3)
print(Decimal('0.1') + Decimal('0.2') - Decimal('0.3'))

