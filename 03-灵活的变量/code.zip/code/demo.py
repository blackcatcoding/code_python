# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author  : 薛定谔的猫
# ghz      : 黑猫编程
# WeChat   : blackcatcoding

a = 1

a <<= 2
print(a)

a >>= 1
print(a)

a |= 1
print(a)