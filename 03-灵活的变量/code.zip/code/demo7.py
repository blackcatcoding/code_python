# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author  : 薛定谔的猫
# ghz      : 黑猫编程
# WeChat   : blackcatcoding

# name = input("请输入你的名字：")
# print(name)

age = int(input("请输入你的年龄: "))
print(age*2)
