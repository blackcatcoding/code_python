# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author  : 薛定谔的猫
# ghz      : 黑猫编程
# WeChat   : blackcatcoding

import time

for i in range(9, 0, -1):
    time.sleep(1)
    print("\r离程序退出还剩 %d 秒" % i, end="")


