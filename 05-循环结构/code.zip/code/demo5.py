# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author  : 薛定谔的猫
# ghz      : 黑猫编程
# WeChat   : blackcatcoding

'''
可迭代对象就是可以重复取值的对象，列表、字符串、字典等
有__iter__方法的对象都是可迭代对象
迭代器，不仅有__iter__方法，还有__next__方法
'''

str1 = "hello"
num = 100

print('__iter__' in dir(str1))
print('__iter__' in dir(num))

li = [1, 2, "hello"]
print(dir(li))

new_li = li.__iter__()  # iter()
print(dir(new_li))

print(new_li.__next__())
print(next(new_li))
print(next(new_li))
# print(next(new_li))