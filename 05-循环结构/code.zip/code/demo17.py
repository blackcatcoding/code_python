# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author  : 薛定谔的猫
# ghz      : 黑猫编程
# WeChat   : blackcatcoding

'''
水仙花数
1.三位数 100-999
2.153 = 1*1*1 + 5*5*5 + 3*3*3
'''

for i in range(100, 1000):
    a = i % 10
    b = i // 10 % 10
    c = i // 100
    if i == a**3 + b**3 + c**3:
        print(i, end="\t")