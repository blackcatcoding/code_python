# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author  : 薛定谔的猫
# ghz      : 黑猫编程
# WeChat   : blackcatcoding

# for i in range(0, 21):
#     for j in range(0, 34):
#         for k in range(0, 301):
#             if (i*5+j*3+k//3==100) and (i+j+k==100) and (k%3==0):
#                 print(i, j, k)

for i in range(0, 21):
    for j in range(0, 34):
        k = 100-i-j
        if (i*5+j*3+k//3==100) and (k%3==0):
            print(i, j, k)