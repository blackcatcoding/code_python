# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author  : 薛定谔的猫
# ghz      : 黑猫编程
# WeChat   : blackcatcoding

'''
鸡兔同笼
35头
94腿
鸡=？ 兔=？
'''

# for i in range(0, 36):
#     for j in range(0, 36):
#         if i*2 + j*4 == 94 and i+j == 35:
#             print(i, j)

for i in range(0, 36):
    j = 35 - i
    if i*2 + j*4 == 94:
        print(i, j)