# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author  : 薛定谔的猫
# ghz      : 黑猫编程
# WeChat   : blackcatcoding

import random

computer = random.randint(1, 100)
player = int(input("num >> "))

cnt = 1
while computer != player:
    if player > computer:
        print("第%d次，猜大了" % cnt)
    if player < computer:
        print("第%d次，猜小了" % cnt)
    player = int(input("num >> "))
    cnt += 1

print("恭喜你，第%d次，猜对了" % cnt)
