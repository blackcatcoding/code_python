# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author  : 薛定谔的猫
# ghz      : 黑猫编程
# WeChat   : blackcatcoding

'''
for循环内部机制：
1.将可迭代对象转化为迭代器
2.利用next取值
3.异常处理
'''

li = [1, 2, "hello"]
new_li = iter(li)

while True:
    try:
        print(next(new_li))
    except StopIteration:
        break