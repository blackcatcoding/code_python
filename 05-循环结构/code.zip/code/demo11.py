# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author  : 薛定谔的猫
# ghz      : 黑猫编程
# WeChat   : blackcatcoding

i = 0

while i <= 10:

    i += 1

    # if i == 6:
    #     break

    print(i)

else:
    print("如果没有break，执行我！")

