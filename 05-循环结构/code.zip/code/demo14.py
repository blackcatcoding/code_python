# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author  : 薛定谔的猫
# ghz      : 黑猫编程
# WeChat   : blackcatcoding

n = int(input("n >> "))

for i in range(1, n+1):
    for j in range(1, n+1):
        print("$", end=" ")
    print()
