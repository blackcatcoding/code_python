# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author  : 薛定谔的猫
# ghz      : 黑猫编程
# WeChat   : blackcatcoding

li = list(range(3, 9, 2))
print(li, type(li))

for i in range(1, 20):
    print(i)