# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author  : 薛定谔的猫
# ghz      : 黑猫编程
# WeChat   : blackcatcoding

i = 1

while i <= 10:
    print(i)
    i += 1
    for j in range(1, 10):
        if j == 3:
            break
        print("执行了内层循环%d次" % j)
