print(520)
print("Hello World.")
print('大家好，我是薛定谔的猫。')

print("I'm 20 years old.", end="    ")

print('I\'m 20 years old.')

print("123\n456")
print("123\t456")   # 行内注释

# 这是单行注释

'''
这是
     多行注释
'''